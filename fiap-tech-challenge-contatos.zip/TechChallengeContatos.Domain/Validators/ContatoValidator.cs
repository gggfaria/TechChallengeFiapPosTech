using FluentValidation;
using TechChallengeContatos.Domain.Contatos;

namespace TechChallengeContatos.Domain.Validators;

public class ContatoValidator : AbstractValidator<Contato>
{
}